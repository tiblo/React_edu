package com.jsframe.bserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BserverApplicationTests {

    @Test
    void contextLoads() {
    }

}
