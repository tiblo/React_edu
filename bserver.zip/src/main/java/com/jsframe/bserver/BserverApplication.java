package com.jsframe.bserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BserverApplication {

    public static void main(String[] args) {
        SpringApplication.run(BserverApplication.class, args);
    }

}
