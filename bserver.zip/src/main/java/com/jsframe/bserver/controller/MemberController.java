package com.jsframe.bserver.controller;

import com.jsframe.bserver.entity.Member;
import com.jsframe.bserver.service.MemberService;
import lombok.extern.java.Log;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@Slf4j
public class MemberController {
    @Autowired
    private MemberService mServ;

    @PostMapping("joinProc")
    public String joinProc(@RequestBody Member member){
        log.info("joinProc");
        String res = mServ.joinMember(member);
        return res;
    }

    @PostMapping("idCheck")
    public Map<String, String> idCheck(@RequestBody Member member){
        log.info("idCheck()");

        return mServ.idCheck(member.getMid());
    }

    @PostMapping("loginProc")
    public Map<String, String> loginProc(@RequestBody Member member){
        log.info("loginProc()");

        return mServ.loginProc(member);
    }
}
