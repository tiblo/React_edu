package com.jsframe.bserver.service;

import com.jsframe.bserver.entity.Member;
import com.jsframe.bserver.repository.MemberRepository;
import lombok.extern.java.Log;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
public class MemberService {
    @Autowired
    MemberRepository mRepo;

    BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    @Transactional
    public String joinMember(Member member){
        log.info("joinMember()");
        String res = null;

        String epwd = encoder.encode(member.getMpwd());
        member.setMpwd(epwd);

        try {
            mRepo.save(member);
            res = "ok";
        }catch (Exception e){
            e.printStackTrace();
            res = "Fail";
        }
        return res;
    }

    public Map<String, String> loginProc(Member member) {
        log.info("loginProc()");
        Member dbMember = null;
        Map<String, String> rsMap = new HashMap<>();
        String result = null;

        try {
            dbMember = mRepo.findById(member.getMid()).get();
            if(encoder.matches(member.getMpwd(), dbMember.getMpwd())){
                //dbMember.setMpwd("");
                rsMap.put("res", "ok");
                rsMap.put("id", member.getMid());
            }
            else {
                //dbMember = null;
                rsMap.put("res", "fail");
                rsMap.put("msg", "비밀번호가 틀립니다.");
            }
        }catch (Exception e){
            e.printStackTrace();
            //dbMember = null;
            rsMap.put("res", "fail");
            rsMap.put("msg", "아이디가 존재하지 않습니다.");
        }
        return rsMap;
    }

    public Map<String, String> idCheck(String mid) {
        log.info("idCheck()");
        Map<String, String> rsMap = new HashMap<>();
        long mcnt = mRepo.countByMid(mid);
        log.info("count : {}", mcnt);

        if(mcnt == 0){
            rsMap.put("res", "ok");
            rsMap.put("msg", "사용 가능한 아이디입니다.");
        }
        else {
            rsMap.put("res", "err");
            rsMap.put("msg", "사용할 수 없는 아이디입니다.");
        }

        return rsMap;
    }
}
